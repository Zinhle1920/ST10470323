/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RC_Student_lab
 */

import java.util.Scanner;

public class MessageManagementPOE {
    static Scanner input = new Scanner(System.in);
    
    // User details
    static String username = "";
    static String password = "";
    static String name = "";
    static String surname = "";

    // Message data
    static int[] messageIDs = {1, 2, 3, 4, 5};
    static String[] senders = {"Zinhle", "Khule", "Atli", "Zinhle", "Khule"};
    static String[] recipients = {
        "+27834557896",
        "+27838884567",
        "+27834484567",
        "0838884567",
        "+27838884567"
    };
    static String[] messages = {
        "Did you get the cake?",
        "Where are you? You are late! I have asked you to be on time.",
        "Yohoooo, I am at your gate.",
        "It is dinner time!",
        "Ok, I am leaving without you."
    };
    static String[] flags = {"Sent", "Sent", "Sent", "Sent", "Sent"};

    // Deleted message tracking
    static int deletedID = -1;
    static String deletedSender = "";
    static String deletedRecipient = "";
    static String deletedMessage = "";
    static String deletedFlag = "";

    public static void main(String[] args) {
        System.out.println("=== Message Management System ===");
        registerUser();
        
        if (!loginUser()) {
            System.out.println("Too many failed attempts. Exiting.");
            return;
        }

        System.out.println("\nWelcome, " + name + " " + surname + " (" + username + ")!");
        showMainMenu();
    }

    public static void registerUser() {
        System.out.println("\n--- Registration ---");
        
        // Name validation
        while (true) {
            System.out.print("Enter your name: ");
            name = input.nextLine().trim();
            if (isValidName(name)) {
                break;
            }
            System.out.println("Invalid name. Only letters and spaces allowed (2-30 characters).");
        }
        
        // Surname validation
        while (true) {
            System.out.print("Enter your surname: ");
            surname = input.nextLine().trim();
            if (isValidName(surname)) {
                break;
            }
            System.out.println("Invalid surname. Only letters and spaces allowed (2-30 characters).");
        }
        
        // Username validation
        while (true) {
            System.out.print("Create a username (must contain _): ");
            username = input.nextLine().trim();
            if (isValidUsername(username)) {
                break;
            }
            System.out.println("""
                Invalid username. Requirements:
                - 4-20 characters
                - Letters, numbers, and underscores only
                - Must contain at least one underscore (_)""");
        }
        
        // Password validation
        while (true) {
            System.out.print("Create a password (must contain letter, number & special char): ");
            password = input.nextLine().trim();
            if (isValidPassword(password)) {
                break;
            }
            System.out.println("""
                Invalid password. Requirements:
                - Minimum 8 characters
                - At least one letter
                - At least one number
                - At least one special character (!@#$%^&*)
                - No spaces""");
        }
        
        System.out.println("\n--- Registration complete ---");
    }

    public static boolean loginUser() {
        for (int i = 0; i < 3; i++) {
            System.out.print("\nEnter username: ");
            String u = input.nextLine().trim();
            System.out.print("Enter password: ");
            String p = input.nextLine().trim();

            if (u.equals(username) && p.equals(password)) {
                return true;
            }
            System.out.println("Incorrect credentials. " + (2-i) + " attempts remaining.");
        }
        return false;
    }

    public static void showMainMenu() {
        int choice;
        do {
            System.out.println("\nMain Menu:");
            System.out.println("1. View all messages");
            System.out.println("2. Search messages");
            System.out.println("3. Delete message");
            System.out.println("4. View deleted message");
            System.out.println("5. Exit");
            System.out.print("Enter choice: ");

            try {
                choice = Integer.parseInt(input.nextLine());
                switch (choice) {
                    case 1:
                        displayAllMessages();
                        break;
                    case 2:
                        searchMessages();
                        break;
                    case 3:
                        deleteMessage();
                        break;
                    case 4:
                        showDeletedMessage();
                        break;
                    case 5:
                        System.out.println("Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter 1-5.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number between 1-5.");
                choice = 0;
            }
        } while (choice != 5);
    }

    // Validation methods
    public static boolean isValidName(String name) {
        return name.matches("[a-zA-Z ]{2,30}");
    }

    static boolean isValidUsername(String username) {
        return username.matches("^[a-zA-Z0-9_]{4,20}$") && username.contains("_");
    }

    static boolean isValidPassword(String password) {
        if (password.length() < 8) return false;
        
        boolean hasLetter = password.matches(".*[a-zA-Z].*");
        boolean hasDigit = password.matches(".*\\d.*");
        boolean hasSpecial = password.matches(".*[!@#$%^&*].*");
        boolean noSpaces = !password.contains(" ");
        
        return hasLetter && hasDigit && hasSpecial && noSpaces;
    }

    // Message management methods
    private static void displayAllMessages() {
        System.out.println("\nAll Messages:");
        for (int i = 0; i < messageIDs.length; i++) {
            System.out.printf("ID: %d | From: %s | To: %s | Status: %s\n%s\n\n",
                messageIDs[i], senders[i], recipients[i], flags[i], messages[i]);
        }
    }

    private static void searchMessages() {
        System.out.print("Enter search term: ");
        String term = input.nextLine().toLowerCase();
        
        System.out.println("\nSearch Results:");
        boolean found = false;
        for (int i = 0; i < messages.length; i++) {
            if (messages[i].toLowerCase().contains(term)) {
                System.out.printf("ID: %d | From: %s | To: %s\n%s\n\n",
                    messageIDs[i], senders[i], recipients[i], messages[i]);
                found = true;
            }
        }
        if (!found) System.out.println("No messages found matching '" + term + "'");
    }

    private static void deleteMessage() {
        System.out.print("Enter message ID to delete: ");
        try {
            int id = Integer.parseInt(input.nextLine());
            boolean deleted = false;
            
            for (int i = 0; i < messageIDs.length; i++) {
                if (messageIDs[i] == id && flags[i].equals("Sent")) {
                    deletedID = messageIDs[i];
                    deletedSender = senders[i];
                    deletedRecipient = recipients[i];
                    deletedMessage = messages[i];
                    deletedFlag = flags[i];
                    flags[i] = "Deleted";
                    deleted = true;
                    break;
                }
            }
            
            System.out.println(deleted ? "Message deleted successfully." : "Message not found or already deleted.");
        } catch (NumberFormatException e) {
            System.out.println("Please enter a valid message ID number.");
        }
    }

    static void showDeletedMessage() {
        if (deletedID == -1) {
            System.out.println("No message has been deleted yet.");
        } else {
            System.out.printf("\nDeleted Message:\nID: %d | From: %s | To: %s\n%s\n",
                deletedID, deletedSender, deletedRecipient, deletedMessage);
        }
    }

    static void deleteMessageByID(int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}