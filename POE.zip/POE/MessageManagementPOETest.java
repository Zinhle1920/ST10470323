/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RC_Student_lab
 */
import org.junit.jupiter.api.*;
import java.io.*;
import static org.junit.jupiter.api.Assertions.*;

class MessageManagementTest {
    private final InputStream originalSystemIn = System.in;
    private final PrintStream originalSystemOut = System.out;
    private ByteArrayOutputStream testOut;

    @BeforeEach
    void setUp() {
        // Reset static variables before each test
        MessageManagementPOE.username = "";
        MessageManagementPOE.password = "";
        MessageManagementPOE.name = "";
        MessageManagementPOE.surname = "";
        MessageManagementPOE.deletedID = -1;
        
        // Redirect System.out to capture output
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
    }

    @AfterEach
    void tearDown() {
        // Restore original System.in and System.out
        System.setIn(originalSystemIn);
        System.setOut(originalSystemOut);
    }

    private void provideInput(String data) {
        // Set up simulated user input
        System.setIn(new ByteArrayInputStream(data.getBytes()));
    }

    @Test
    void testMainWithSuccessfulRegistrationAndLogin() throws Exception {
        String input = "John\nDoe\nj_doe\nPassword123!\n" +  // Registration
                      "j_doe\nPassword123!\n" +            // Login
                      "5\n";                                // Exit
        provideInput(input);

        MessageManagementPOE.main(new String[]{});

        String output = testOut.toString();
        assertTrue(output.contains("Registration complete"));
        assertTrue(output.contains("Welcome, John Doe (j_doe)"));
    }

    @Test
    void testRegistrationWithInvalidInputs() throws Exception {
        String input = "J0hn\nJohn\nD03\nDoe\njdoe\nj_doe\npass\npass123\nPassword123!\n";
        provideInput(input);

        MessageManagementPOE.registerUser();

        String output = testOut.toString();
        assertTrue(output.contains("Invalid name"));
        assertTrue(output.contains("Invalid surname"));
        assertTrue(output.contains("Invalid username"));
        assertTrue(output.contains("Invalid password"));
        assertTrue(output.contains("Registration complete"));
    }

    @Test
    void testLoginWithInvalidCredentials() throws Exception {
        // First register a user
        MessageManagementPOE.username = "test_user";
        MessageManagementPOE.password = "Test123!";
        
        String input = "wrong_user\nwrong_pass\n" +
                      "test_user\nwrong_pass\n" +
                      "test_user\nTest123!\n";
        provideInput(input);

        assertTrue(MessageManagementPOE.loginUser());  // Should succeed on 3rd try
        
        String output = testOut.toString();
        assertTrue(output.contains("Incorrect credentials"));
        assertTrue(output.contains("2 attempts remaining"));
    }

    @Test
    void testPasswordValidation() {
        assertFalse(MessageManagementPOE.isValidPassword("short"));
        assertFalse(MessageManagementPOE.isValidPassword("nospcialchars1"));
        assertFalse(MessageManagementPOE.isValidPassword("NoNumbers!"));
        assertFalse(MessageManagementPOE.isValidPassword("12345678!"));
        assertFalse(MessageManagementPOE.isValidPassword("Has space 1!"));
        
        assertTrue(MessageManagementPOE.isValidPassword("Valid123!"));
        assertTrue(MessageManagementPOE.isValidPassword("Another@1"));
    }

    @Test
    void testUsernameValidation() {
        assertFalse(MessageManagementPOE.isValidUsername("no underscore"));
        assertFalse(MessageManagementPOE.isValidUsername("tooshort_"));
        assertFalse(MessageManagementPOE.isValidUsername("_"));
        assertFalse(MessageManagementPOE.isValidUsername("invalid-chars_"));
        
        assertTrue(MessageManagementPOE.isValidUsername("valid_user"));
        assertTrue(MessageManagementPOE.isValidUsername("u_1234567890"));
    }

    @Test
    void testMessageDeletion() {
        // Setup test message
        MessageManagementPOE.messageIDs = new int[]{1};
        MessageManagementPOE.senders = new String[]{"Test"};
        MessageManagementPOE.recipients = new String[]{"123"};
        MessageManagementPOE.messages = new String[]{"Test message"};
        MessageManagementPOE.flags = new String[]{"Sent"};

        MessageManagementPOE.deleteMessageByID(1);
        
        assertEquals(1, MessageManagementPOE.deletedID);
        assertEquals("Deleted", MessageManagementPOE.flags[0]);
    }

    @Test
    void testShowDeletedMessage() {
        MessageManagementPOE.deletedID = 1;
        MessageManagementPOE.deletedSender = "Test";
        MessageManagementPOE.deletedRecipient = "123";
        MessageManagementPOE.deletedMessage = "Test message";
        
        MessageManagementPOE.showDeletedMessage();
        
        String output = testOut.toString();
        assertTrue(output.contains("Deleted Message"));
        assertTrue(output.contains("Test message"));
    }
}
